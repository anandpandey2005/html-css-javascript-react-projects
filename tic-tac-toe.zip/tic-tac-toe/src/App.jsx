import { useState } from "react";
import "./App.css";

function App() {
  const [player1Name, setPlayer1Name] = useState("");
  const [player2Name, setPlayer2Name] = useState("");
  const [isSetPlayer1Name, setIsSetPlayer1Name] = useState(false);
  const [isSetPlayer2Name, setIsSetPlayer2Name] = useState(false);
  const [score1, setScore1] = useState(0);
  const [score2, setScore2] = useState(0);
  const [count, setCount] = useState("X");
  const [playedTimes, setPlayedTimes] = useState(0);
  const [board, setBoard] = useState(Array(9).fill(""));
  const [showPrompt, setShowPrompt] = useState(false);
  const [currentPlayer, setCurrentPlayer] = useState(null);
  const [tempName, setTempName] = useState("");
  const [winner, setWinner] = useState(null);
  const [isDraw, setIsDraw] = useState(false);

  function setUserName(playerNumber) {
    setCurrentPlayer(playerNumber);
    setTempName("");
    setShowPrompt(true);
  }

  function handleConfirmName() {
    if (!tempName.trim()) return;
    if (currentPlayer === 1) {
      setPlayer1Name(tempName);
      setIsSetPlayer1Name(true);
    } else if (currentPlayer === 2) {
      setPlayer2Name(tempName);
      setIsSetPlayer2Name(true);
    }
    setShowPrompt(false);
  }

  function checkWinner(board, symbol) {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    return lines.some(
      ([a, b, c]) =>
        board[a] === symbol && board[b] === symbol && board[c] === symbol
    );
  }

  function handleClick(key) {
    if (board[key] !== "" || winner || isDraw) return;

    const clickSound = new Audio("/click.mp3");
    clickSound.play();

    const newBoard = [...board];
    newBoard[key] = count;
    setBoard(newBoard);

    const currentPlayerMark = count;
    const nextPlayerMark = count === "X" ? "O" : "X";
    const playerName = currentPlayerMark === "X" ? player1Name : player2Name;

    if (checkWinner(newBoard, currentPlayerMark)) {
      const winSound = new Audio("/music.mp3");
      winSound.play();
      setWinner(playerName);
      if (currentPlayerMark === "X") setScore1(score1 + 1);
      else setScore2(score2 + 1);
      setPlayedTimes(playedTimes + 1);
    } else if (newBoard.every((cell) => cell !== "")) {
      setIsDraw(true);
      setPlayedTimes(playedTimes + 1);
    } else {
      setCount(nextPlayerMark);
    }
  }

  function resetGame() {
    setBoard(Array(9).fill(""));
    setCount("X");
    setWinner(null);
    setIsDraw(false);
  }

  return (
    <>
      <section className="w-full min-h-screen flex flex-col bg-black px-4 sm:px-6 md:px-10">
        <div className="flex flex-col sm:flex-row justify-between items-center sm:items-stretch p-4 border-2 border-gray-700 text-white gap-4 sm:gap-0">
          <div className="text-center sm:text-left">
            <span onClick={() => setUserName(1)} className="cursor-pointer">
              X = {isSetPlayer1Name ? player1Name : "click to set Name"}
            </span>
            :
            <span className="ml-2 py-1 px-3 rounded border-2 border-yellow-500 inline-block">
              {score1}
            </span>
          </div>

          <div className="text-center sm:text-left">
            Played Times: {playedTimes}
          </div>

          <div className="text-center sm:text-left">
            <span onClick={() => setUserName(2)} className="cursor-pointer">
              O = {isSetPlayer2Name ? player2Name : "click to set Name"}
            </span>
            :
            <span className="ml-2 py-1 px-3 rounded border-2 border-yellow-500 inline-block">
              {score2}
            </span>
          </div>
        </div>

        {isSetPlayer1Name && isSetPlayer2Name ? (
          <div className="w-full mt-10 mx-auto flex justify-center items-center">
            <div className="w-full max-w-sm sm:max-w-md bg-yellow-500 border-10 border-red-900 rounded-2xl p-5">
              <div className="w-full aspect-square bg-white border-4 border-red-950 p-2 grid grid-cols-3 gap-2">
                {board.map((value, key) => (
                  <div
                    key={key}
                    className="aspect-square w-full border-2 border-black text-center flex justify-center items-center text-xl sm:text-2xl font-bold cursor-pointer"
                    onClick={() => handleClick(key)}
                  >
                    {value}
                  </div>
                ))}
              </div>
              {winner && (
                <>
                  <div className="mt-6 text-center text-2xl font-bold text-green-400 bg-black border border-green-600 rounded-lg p-3">
                    🎉 {winner} wins this round!
                  </div>
                  <div className="text-center mt-4">
                    <button
                      onClick={resetGame}
                      className="px-4 py-2 bg-yellow-500 text-black rounded hover:bg-yellow-400 transition"
                    >
                      Play Again
                    </button>
                  </div>
                </>
              )}
              {isDraw && !winner && (
                <>
                  <div className="mt-6 text-center text-2xl font-bold text-blue-400 bg-black border border-blue-600 rounded-lg p-3">
                    🤝 It's a Draw!
                  </div>
                  <div className="text-center mt-4">
                    <button
                      onClick={resetGame}
                      className="px-4 py-2 bg-yellow-500 text-black rounded hover:bg-yellow-400 transition"
                    >
                      Play Again
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        ) : (
          <p className="text-center text-lg font-semibold mt-10 text-red-600">
            Please set player names to start the game.
          </p>
        )}

        <div className="flex flex-col mx-auto mt-10 py-4 px-4 sm:px-6 max-w-2xl">
          <h1 className="text-yellow-500 text-3xl sm:text-4xl font-bold tracking-wide text-center">
            INSTRUCTIONS !
          </h1>
          <ul className="text-white list-disc list-inside mt-4 space-y-2 text-base sm:text-lg">
            <li>
              Click on "click to set Name" to set Player X and Player O names.
            </li>
            <li>Once both names are set, the Tic-Tac-Toe board will appear.</li>
            <li>Player X always starts first.</li>
            <li>Click on any empty box to place your mark (X or O).</li>
            <li>Players take turns one by one.</li>
            <li>
              First player to align 3 of their marks in a row, column, or
              diagonal wins!
            </li>
            <li>
              If all boxes are filled without a winner, the game ends in a draw.
            </li>
            <li>
              Keep track of scores and the number of games played at the top.
            </li>
          </ul>
          <a href="https://anandpandey2005.netlify.app" target="_blank">
            <button
              type="button"
              className="text-yellow-500 w-20 border-2 text-center mx-[40%] mt-10"
            >
              Portfolio
            </button>
          </a>
        </div>
      </section>

      {showPrompt && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
          <div className="bg-gray-900 text-white p-6 rounded-xl border-2 border-yellow-500 shadow-lg w-11/12 max-w-sm">
            <h2 className="text-xl font-bold mb-4 text-center">
              Enter Player Name
            </h2>
            <input
              type="text"
              className="w-full p-2 mb-4 rounded bg-black border border-gray-500 focus:outline-none focus:border-yellow-500 text-white"
              placeholder="Type name here..."
              value={tempName}
              onChange={(e) => setTempName(e.target.value)}
            />
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowPrompt(false)}
                className="px-4 py-1 bg-red-600 rounded hover:bg-red-700 transition"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmName}
                className="px-4 py-1 bg-yellow-500 text-black rounded hover:bg-yellow-400 transition font-semibold"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default App;

import Navbar from './components/Navbar';
import InputText from './components/Text';
function App() {
    return (
        <>
            <Navbar tittle="Text ◯peration" />
            <InputText></InputText>
        </>
    );
}

export default App;  
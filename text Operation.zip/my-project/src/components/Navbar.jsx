import React,{useState} from "react";
import PropTypes from 'prop-types'
function Navbar(props){
    return(
        <>
        <nav className="w-full pt-7 pb-7 text-center text-gray-200 bg-black fixed">
        <h1 className="text-xl font-bold uppercase">{props.tittle}</h1>
        </nav>
        </>
    )
}
Navbar.prototype = {tittle:PropTypes.string}
Navbar.defaultProps = {
    tittle: 'text utils'
}
export default Navbar;
import React, { useState } from 'react';

export default function InputText() {
  const playSound = () => {
    const audio = new Audio('/Mouse-Click-Sound-Effect.mp3'); 
    audio.play();
  };

  const [text, setText] = useState('');

  const uppercase = () => {
    setText(text.toUpperCase());
  };

  const lowercase = () => {
    setText(text.toLowerCase());
  };

  const capitalize = () => {
    const capitalizedText = text.split(' ').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
    setText(capitalizedText);
  };

  const reverse = () => {
    const reversedText = text.split('').reverse().join('');
    setText(reversedText);
  };

  const handleChange = (event) => {
    setText(event.target.value);
  };

  return (
    <>
      <div className='flex justify-center'>  
        <textarea 
          className="p-[10px] border-[5px] mt-40 placeholder:text-center placeholder:text-2xl border-black hover:border-blue-600 focus:border-blue-600 placeholder-red-500 resize-none" 
          cols="70" 
          rows="10"
          placeholder='Enter Text....'
          value={text}
          onChange={handleChange} 
        >
        </textarea>
      </div>
      <div className='flex justify-center mt-4 flex-wrap'>
        <button type="button" className='p-2 m-1 border-[2px] border-black rounded-2xl hover:border-black hover:text-black hover:bg-slate-400 bg-black text-white' onClick={() => { playSound(); uppercase(); }}>Uppercase</button>
        <button type="button" className='p-2 m-1 border-[2px] border-black rounded-2xl hover:border-black hover:text-black hover:bg-slate-400 bg-black text-white' onClick={() => { playSound(); lowercase(); }}>Lowercase</button>
        <button type="button" className='p-2 m-1 border-[2px] border-black rounded-2xl hover:border-black hover:text-black hover:bg-slate-400 bg-black text-white' onClick={() => { playSound(); capitalize(); }}>Capitalize</button>
        <button type="button" className='p-2 m-1 border-[2px] border-black rounded-2xl hover:border-black hover:text-black hover:bg-slate-400 bg-black text-white' onClick={() => { playSound(); reverse(); }}>Reverse</button>
        
      </div>
      <div className='flex justify-center mt-4 flex-wrap'>
        <div className="summary">
        <table class="min-w-full  bg-white shadow-md rounded-lg overflow-hidden">
        <thead>
            <tr className="bg-slate-950 text-white">
                <th class="py-3 px-4 text-left">Summary</th>
                <th class="py-3 px-4 text-left">Count</th>
            </tr>
        </thead>
        <tbody>
            <tr class="hover:bg-gray-200">
                <td class="py-3 px-4 border-b">Characters</td>
                <td class="py-3 px-4 border-b">{text.length}</td>
            </tr>
            <tr class="hover:bg-gray-200">
                <td class="py-3 px-4 border-b">Words</td>
                <td class="py-3 px-4 border-b">{text.trim() ? text.trim().split(/\s+/).length : 0}</td>
            </tr>
            <tr class="hover:bg-gray-200">
                <td class="py-3 px-4 border-b">Lines</td>
                <td class="py-3 px-4 border-b">{text.trim() ? text.trim().split('\n').length : 0}</td>
            </tr>
            <tr class="hover:bg-gray-200">
                <td class="py-3 px-4 border-b">Paragraphs</td>
                <td class="py-3 px-4 border-b">{text.trim() ? text.trim().split(/\n+/).length : 0}</td>
            </tr>
            <tr class="hover:bg-gray-200">
                <td class="py-3 px-4 border-b">Average Word Length</td>
                <td class="py-3 px-4 border-b">
                    {text.trim() ? (text.trim().split(/\s+/).reduce((total, word) => total + word.length, 0) / text.trim().split(/\s+/).length).toFixed(2) : 0}
                </td>
            </tr>
            <tr class="hover:bg-gray-200">
                <td class="py-3 px-4 border-b">Longest Word</td>
                <td class="py-3 px-4 border-b">
                    {text.trim() ? text.trim().split(/\s+/).reduce((longest, word) => word.length > longest.length ? word : longest, '').length > 0 ? text.trim().split(/\s+/).reduce((longest, word) => word.length > longest.length ? word : longest, '') : 'N/A' : 'N/A'}
                </td>
            </tr>
        </tbody>
    </table>
        </div>
      </div>
    </>
  );
}